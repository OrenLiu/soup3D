from setuptools import setup

setup(
    name='soup3D',
    version='3.2.2',
    packages=['soup3D'],
    package_data={
        "soup3D": ["*.png"],
    }
)

