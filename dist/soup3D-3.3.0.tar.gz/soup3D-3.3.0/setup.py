from setuptools import setup

setup(
    name='soup3D',
    version='3.3.0',
    packages=['soup3D'],
    install_requires=[
        'PyOpenGL',
        'pyglm',
        'Pillow',
        'numpy',
        'pygame'
    ]
)

