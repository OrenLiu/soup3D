from setuptools import setup

setup(
    name='soup3D',
    version='2.2.1',
    packages=['soup3D']
)

