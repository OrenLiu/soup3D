# soup3D

A 3D engine based on OpenGL and pygame, designed for beginners to learn and use in 3D game development, data visualization, and 3D graphics rendering.

## Features

- Easy to learn and use
- Suitable for 3D game development
- Data visualization capabilities
- 3D graphics rendering
- Built-in lighting and camera systems
- Support for OBJ/MTL model loading
- Shader support with automatic program generation

## Installation

You can install soup3D using pip:

```bash
pip install soup3D
```

Or install from source:

```bash
pip install -i https://osoup.top/simple soup3D
```

## Quick Start

Here's a simple example to get you started:

```python
import soup3D  # 3D rendering library
import pygame  # pygame window library for displaying soup3D rendered images

if __name__ == '__main__':
    pygame.init()                                                            # Initialize pygame
    pygame.display.set_caption("soup3D")                                     # Set pygame window title
    pygame.display.set_mode((1920, 1080), pygame.DOUBLEBUF | pygame.OPENGL)  # Configure window mode
    soup3D.init(bg_color=(1, 1, 1), width=1920, height=1080)                 # Initialize soup3D

    soup3D.light.ambient(1, 1, 1)  # Set ambient light to maximum

    surface = soup3D.shader.AutoSP(soup3D.shader.MixChannel((1, 1), 1, 0.5, 0))  # Create orange surface shader
    face = soup3D.Face(  # Create a right triangle
        soup3D.TRIANGLE_L,
        surface,
        (
            (0, 0, 0, 0, 0),  # (x, y, z, u, v)
            (1, 0, 0, 0, 0),
            (0, 1, 0, 0, 0)
        )
    )
    model = soup3D.Model(0, 0, -5, face)  # Add triangle to model
    model.show()  # Display model

    running = True  # Running state
    while running:  # Main loop
        soup3D.update()  # Update soup3D
        pygame.display.flip()  # Refresh pygame display
        for event in pygame.event.get():  # Iterate through all events
            if event.type == pygame.QUIT:  # Check for window close event
                pygame.quit()  # Close window
                running = False  # End loop
```

After running this code with proper environment configuration, you will see an orange triangle in the window.

## Dependencies

- PyOpenGL
- pyglm
- Pillow
- numpy
- pygame

## Documentation

For more detailed information about the API, please refer to the [help documentation](soup3D/help.md).

## Contributing

We welcome contributions from the community! To maintain code quality and consistency, please follow these guidelines:

1. All functions, classes, and methods must have Google-style docstring comments
2. Test your code before submitting a pull request
3. Coordinate with the maintainers before implementing new features
4. Try to maintain backward compatibility when adding new features

## License

This project is licensed under the MIT License. See the [LICENSE](soup3D/LICENSE) file for details.