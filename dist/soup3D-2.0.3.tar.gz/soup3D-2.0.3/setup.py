from setuptools import setup

setup(
    name='soup3D',
    version='2.0.3',
    packages=['soup3D']
)

