from setuptools import setup

setup(
    name='soup3D',
    version='4.2.1',
    packages=['soup3D'],
    install_requires=[
        'PyOpenGL',
        'pyglm',
        'Pillow',
        'numpy',
        'pygame'
    ]
)
