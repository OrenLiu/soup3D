from setuptools import setup

setup(
    name='soup3D',
    version='1.1.2',
    packages=['soup3D']
)

