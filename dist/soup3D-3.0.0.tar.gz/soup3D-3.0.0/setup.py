from setuptools import setup

setup(
    name='soup3D',
    version='3.0.0',
    packages=['soup3D']
)

