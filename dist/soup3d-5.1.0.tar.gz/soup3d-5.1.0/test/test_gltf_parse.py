"""
测试GLTF文件解析功能（不渲染）
"""
import sys
import os
import json

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_gltf_parsing():
    """测试GLTF文件解析，不进行渲染"""
    print("=" * 60)
    print("测试GLTF模型解析（无渲染）")
    print("=" * 60)

    gltf_path = "./oren/oren.gltf"

    if not os.path.exists(gltf_path):
        print(f"错误: 文件不存在: {gltf_path}")
        return

    print(f"\n加载文件: {gltf_path}")

    try:
        # 直接读取和解析glTF JSON
        with open(gltf_path, 'r', encoding='utf-8') as f:
            gltf_data = json.load(f)

        print(f"\n✓ JSON解析成功!")

        # 检查glTF结构
        print(f"\nglTF文件信息:")
        print(f"  - asset.version: {gltf_data.get('asset', {}).get('version', 'N/A')}")
        print(f"  - scene: {gltf_data.get('scene', 'default')}")
        print(f"  - scenes数量: {len(gltf_data.get('scenes', []))}")
        print(f"  - nodes数量: {len(gltf_data.get('nodes', []))}")
        print(f"  - meshes数量: {len(gltf_data.get('meshes', []))}")
        print(f"  - skins数量: {len(gltf_data.get('skins', []))}")
        print(f"  - accessors数量: {len(gltf_data.get('accessors', []))}")
        print(f"  - bufferViews数量: {len(gltf_data.get('bufferViews', []))}")
        print(f"  - buffers数量: {len(gltf_data.get('buffers', []))}")
        print(f"  - materials数量: {len(gltf_data.get('materials', []))}")
        print(f"  - textures数量: {len(gltf_data.get('textures', []))}")
        print(f"  - images数量: {len(gltf_data.get('images', []))}")

        # 检查场景节点
        if 'scenes' in gltf_data and gltf_data['scenes']:
            scene = gltf_data['scenes'][gltf_data.get('scene', 0)]
            print(f"\n主场景节点: {scene.get('nodes', [])}")

        # 检查网格
        if 'meshes' in gltf_data and gltf_data['meshes']:
            print(f"\n网格信息:")
            for i, mesh in enumerate(gltf_data['meshes']):
                print(f"  Mesh[{i}]: {mesh.get('name', 'unnamed')}")
                print(f"    - primitives数量: {len(mesh.get('primitives', []))}")
                for j, prim in enumerate(mesh.get('primitives', [])):
                    print(f"      Primitive[{j}]:")
                    print(f"        - mode: {prim.get('mode', 4)}")
                    print(f"        - attributes: {list(prim.get('attributes', {}).keys())}")
                    print(f"        - indices: {prim.get('indices', 'N/A')}")
                    print(f"        - material: {prim.get('material', 'N/A')}")

        # 检查皮肤（骨骼）
        if 'skins' in gltf_data and gltf_data['skins']:
            print(f"\n皮肤/骨骼信息:")
            for i, skin in enumerate(gltf_data['skins']):
                print(f"  Skin[{i}]: {skin.get('name', 'unnamed')}")
                print(f"    - joints数量: {len(skin.get('joints', []))}")
                print(f"    - inverseBindMatrices: {skin.get('inverseBindMatrices', 'N/A')}")
                print(f"    - skeleton: {skin.get('skeleton', 'N/A')}")

        # 检查材质
        if 'materials' in gltf_data and gltf_data['materials']:
            print(f"\n材质信息:")
            for i, material in enumerate(gltf_data['materials'][:5]):  # 只显示前5个
                print(f"  Material[{i}]: {material.get('name', 'unnamed')}")
                if 'pbrMetallicRoughness' in material:
                    pbr = material['pbrMetallicRoughness']
                    print(f"    - baseColor: {pbr.get('baseColorFactor', 'N/A')}")
                    print(f"    - metallic: {pbr.get('metallicFactor', 'N/A')}")
                    print(f"    - roughness: {pbr.get('roughnessFactor', 'N/A')}")

        print("\n" + "=" * 60)
        print("基础解析测试通过! ✓")
        print("=" * 60)

        # 现在尝试使用soup3D的解析函数
        print("\n尝试使用soup3D的内部解析函数...")

        # 导入soup3D模块
        import soup3D

        # 测试内部函数（不创建渲染对象）
        base_dir = os.path.dirname(gltf_path)

        # 检查读取accessor的函数
        if hasattr(soup3D, '_read_accessor'):
            print("✓ _read_accessor 函数存在")
        else:
            print("✗ _read_accessor 函数不存在")

        # 检查构建骨骼的函数
        if hasattr(soup3D, '_build_skeleton'):
            print("✓ _build_skeleton 函数存在")
        else:
            print("✗ _build_skeleton 函数不存在")

        # 检查构建网格的函数
        if hasattr(soup3D, '_build_mesh'):
            print("✓ _build_mesh 函数存在")
        else:
            print("✗ _build_mesh 函数不存在")

        print("\n所有核心解析函数都已实现! ✓")

    except Exception as e:
        print(f"\n✗ 解析失败!")
        print(f"  错误类型: {type(e).__name__}")
        print(f"  错误信息: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_gltf_parsing()
