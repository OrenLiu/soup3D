"""
测试GLTF数据加载（不创建OpenGL对象）
"""
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_gltf_data_loading():
    """测试GLTF文件数据加载（不渲染）"""
    print("=" * 60)
    print("测试GLTF模型数据加载（不渲染）")
    print("=" * 60)

    gltf_path = "./oren/oren.gltf"

    if not os.path.exists(gltf_path):
        print(f"错误: 文件不存在: {gltf_path}")
        return

    print(f"\n加载文件: {gltf_path}")

    try:
        import soup3D

        # 我们需要模拟open_gltf但是不创建实际的Face对象
        # 因为Face对象会尝试编译shader

        # 手动执行open_gltf的前半部分
        import json
        import numpy as np

        # 读取glTF文件
        with open(gltf_path, 'r', encoding='utf-8') as f:
            gltf_data = json.load(f)

        base_dir = os.path.dirname(gltf_path)

        # 加载 buffer 数据
        buffers = []
        buffer_defs = gltf_data.get("buffers", [])

        for buf_def in buffer_defs:
            if "uri" in buf_def:
                uri = buf_def["uri"]
                if uri.endswith(".bin"):
                    bin_path = os.path.join(base_dir, uri)
                    with open(bin_path, 'rb') as bin_file:
                        buffers.append(bin_file.read())

        # 获取 glTF 各部分
        accessors = gltf_data.get("accessors", [])
        buffer_views = gltf_data.get("bufferViews", [])
        nodes = gltf_data.get("nodes", [])
        meshes = gltf_data.get("meshes", [])
        skins = gltf_data.get("skins", [])
        scenes = gltf_data.get("scenes", [])
        scene = gltf_data.get("scene", 0)

        print(f"\n✓ 文件解析成功")
        print(f"  - 节点数量: {len(nodes)}")
        print(f"  - 网格数量: {len(meshes)}")
        print(f"  - 皮肤数量: {len(skins)}")

        # 构建骨架
        skeleton = None
        if skins:
            skin = skins[0]
            skeleton = soup3D._build_skeleton(skin, nodes, accessors, buffer_views, buffers)
            print(f"  - 骨骼数量: {len(skeleton.bones)}")

        # 分析网格数据（不创建Face对象）
        total_vertices = 0
        total_faces = 0
        mesh_info = []

        for mesh_idx, mesh in enumerate(meshes):
            mesh_name = mesh.get('name', f'mesh_{mesh_idx}')
            primitives = mesh.get('primitives', [])

            for prim_idx, primitive in enumerate(primitives):
                attributes = primitive.get('attributes', {})

                # 统计顶点
                if 'POSITION' in attributes:
                    pos_accessor_idx = attributes['POSITION']
                    pos_accessor = accessors[pos_accessor_idx]
                    vertex_count = pos_accessor.get('count', 0)
                    total_vertices += vertex_count

                # 统计面（索引）
                if 'indices' in primitive:
                    indices_accessor_idx = primitive['indices']
                    indices_accessor = accessors[indices_accessor_idx]
                    index_count = indices_accessor.get('count', 0)
                    face_count = index_count // 3  # 每个面3个顶点
                    total_faces += face_count

                mesh_info.append({
                    'name': f"{mesh_name}_prim_{prim_idx}",
                    'vertices': vertex_count,
                    'faces': face_count,
                    'attributes': list(attributes.keys())
                })

        print(f"\n✓ 网格数据分析")
        print(f"  - 总顶点数: {total_vertices}")
        print(f"  - 总面数: {total_faces}")

        print(f"\n✓ 网格详情 (前5个):")
        for i, info in enumerate(mesh_info[:5]):
            print(f"  [{i}] {info['name']}:")
            print(f"      - 顶点数: {info['vertices']}")
            print(f"      - 面数: {info['faces']}")
            print(f"      - 属性: {info['attributes']}")

        if len(mesh_info) > 5:
            print(f"  ... 还有 {len(mesh_info) - 5} 个网格")

        print("\n" + "=" * 60)
        print("数据加载测试通过! ✓")
        print("=" * 60)

        # 检查是否有骨骼绑定
        if skeleton and len(skeleton.bones) > 0:
            print(f"\n✓ 骨骼绑定检测")
            print(f"  - 骨骼系统已加载: {len(skeleton.bones)} 个骨骼")

            # 检查是否有蒙皮网格
            has_skin = any('JOINTS_0' in prim.get('attributes', {}) for mesh in meshes for prim in mesh.get('primitives', []))
            if has_skin:
                print(f"  - 检测到蒙皮网格（带骨骼权重）")

        return True

    except Exception as e:
        print(f"\n✗ 加载失败!")
        print(f"  错误类型: {type(e).__name__}")
        print(f"  错误信息: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_gltf_data_loading()
    sys.exit(0 if success else 1)
