"""
测试骨骼长度是否正确设置（修复 bone.length 的同时更新）
"""
import sys
import os
import math
sys.path.insert(0, '.')

try:
    # 导入 soup3D.skeleton 模块
    import soup3D.skeleton as skeleton_module

    # 创建一个测试骨骼
    bone = skeleton_module.Bone(
        init_pos=(0, 0, 0),
        init_length=2.5,
        init_toward=(0, 0, 0)
    )

    print("=" * 60)
    print("测试骨骼长度属性")
    print("=" * 60)

    print(f"\n创建骨骼:")
    print(f"  init_length: {bone.init_length}")
    print(f"  length:      {bone.length}")

    # 修改 init_length
    print(f"\n修改 init_length 为 5.0:")
    bone.init_length = 5.0
    print(f"  init_length: {bone.init_length}")
    print(f"  length:      {bone.length}")

    print(f"\n结论: 修改 init_length 不会自动更新 length")
    print(f"      所以我们需要同时更新两个属性")

    # 测试同时更新
    print(f"\n同时更新两个属性:")
    bone.init_length = 3.5
    bone.length = 3.5
    print(f"  init_length: {bone.init_length}")
    print(f"  length:      {bone.length}")

    # 测试 _get_end_position
    print(f"\n测试 _get_end_position():")
    end_pos = bone._get_end_position()
    print(f"  骨骼根位置: ({bone.pos.x}, {bone.pos.y}, {bone.pos.z})")
    print(f"  骨骼末端位置: ({end_pos[0]:.4f}, {end_pos[1]:.4f}, {end_pos[2]:.4f})")

    # 计算预期的末端位置（Z轴正方向，长度3.5）
    print(f"\n验证: 骨骼长度应为 {bone.length}")
    print(f"      末端到根的距离: {math.sqrt(sum([x**2 for x in end_pos])):.4f}")

    print("\n" + "=" * 60)
    print("修复确认: _build_skeleton Pass 2 现在同时更新")
    print("            bone.init_length 和 bone.length")
    print("=" * 60)

except Exception as e:
    print(f"\n✗ 测试失败!")
    print(f"  错误类型: {type(e).__name__}")
    print(f"  错误信息: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
