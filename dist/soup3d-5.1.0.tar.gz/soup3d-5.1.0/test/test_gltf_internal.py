"""
测试GLTF内部解析函数
"""
import sys
import os
import json

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_internal_functions():
    """测试内部解析函数"""
    print("=" * 60)
    print("测试GLTF内部解析函数")
    print("=" * 60)

    gltf_path = "./oren/oren.gltf"

    if not os.path.exists(gltf_path):
        print(f"错误: 文件不存在: {gltf_path}")
        return

    print(f"\n加载文件: {gltf_path}")

    try:
        import soup3D

        # 读取glTF数据
        with open(gltf_path, 'r', encoding='utf-8') as f:
            gltf_data = json.load(f)

        base_dir = os.path.dirname(gltf_path)

        print(f"\n✓ glTF数据加载成功")

        # 测试1: 读取buffer
        print(f"\n测试1: 读取buffer数据")
        # 手动读取buffer数据（模拟open_gltf中的逻辑）
        buffers = []
        buffer_defs = gltf_data.get("buffers", [])

        for buf_def in buffer_defs:
            if "uri" in buf_def:
                uri = buf_def["uri"]
                if uri.endswith(".bin"):
                    bin_path = os.path.join(base_dir, uri)
                    with open(bin_path, 'rb') as bin_file:
                        buffers.append(bin_file.read())

        # 使用第一个buffer进行测试
        if buffers:
            buffer_data = buffers[0]
            print(f"  ✓ Buffer大小: {len(buffer_data)} bytes")
        else:
            print(f"  ✗ 未找到buffer数据")
            return

        # 测试2: 读取accessor
        print(f"\n测试2: 读取accessor数据")
        if 'accessors' in gltf_data and gltf_data['accessors']:
            accessor = gltf_data['accessors'][0]
            # 手动实现accessor读取逻辑
            buffer_views = gltf_data.get('bufferViews', [])

            if 'bufferView' in accessor:
                buffer_view_idx = accessor['bufferView']
                buffer_view = buffer_views[buffer_view_idx]

                buffer_idx = buffer_view.get('buffer', 0)
                offset = buffer_view.get('byteOffset', 0)
                length = buffer_view.get('byteLength', 0)

                # 添加accessor偏移
                offset += accessor.get('byteOffset', 0)

                # 读取数据
                import numpy as np
                data_bytes = buffers[buffer_idx][offset:offset + length]

                # 根据类型解析数据
                component_type = accessor.get('componentType', 5126)  # 默认float
                data_type = accessor.get('type', 'SCALAR')
                count = accessor.get('count', 0)

                # 创建numpy数组
                dtype = np.float32
                data = np.frombuffer(data_bytes, dtype=dtype)

                print(f"  ✓ Accessor[0]数据类型: {type(data)}")
                print(f"  ✓ Accessor[0]数据形状: {data.shape}")
                print(f"  ✓ Accessor[0]前5个值: {data[:5]}")
            else:
                print(f"  ✗ Accessor没有bufferView")

        # 测试3: 构建骨骼
        print(f"\n测试3: 构建骨骼系统")
        if 'skins' in gltf_data and gltf_data['skins']:
            skin = gltf_data['skins'][0]
            # 测试_build_skeleton函数
            try:
                # 准备参数
                nodes = gltf_data.get('nodes', [])
                accessors = gltf_data.get('accessors', [])
                buffer_views = gltf_data.get('bufferViews', [])

                # 测试调用_build_skeleton
                skeleton = soup3D._build_skeleton(skin, nodes, accessors, buffer_views, buffers)

                # Skeleton对象通过bones属性访问骨骼
                bone_names = list(skeleton.bones.keys())
                print(f"  ✓ 骨骼数量: {len(bone_names)}")

                # 显示前几个骨骼
                first_bones = bone_names[:5]
                print(f"  ✓ 前5个骨骼名称: {first_bones}")

                # 检查骨骼结构
                for bone_name in first_bones:
                    bone = skeleton.bones[bone_name]
                    print(f"    - {bone_name}: pos={bone.pos}, toward={bone.toward}, length={bone.length}")
            except Exception as e:
                print(f"  ✗ 骨骼构建失败: {e}")
                import traceback
                traceback.print_exc()

        # 测试4: 构建网格
        print(f"\n测试4: 构建网格数据")
        if 'meshes' in gltf_data and gltf_data['meshes']:
            mesh = gltf_data['meshes'][0]
            print(f"  - 网格名称: {mesh.get('name', 'unnamed')}")

            if 'primitives' in mesh and mesh['primitives']:
                primitive = mesh['primitives'][0]

                # 这里我们不测试完整的_build_mesh，因为它会创建Face对象
                # 而Face对象可能会尝试编译shader
                # 我们只测试原始数据的读取

                # 测试读取顶点位置
                if 'attributes' in primitive:
                    attributes = primitive['attributes']

                    if 'POSITION' in attributes:
                        pos_accessor_idx = attributes['POSITION']
                        pos_accessor = gltf_data['accessors'][pos_accessor_idx]
                        # 手动读取数据
                        buffer_views = gltf_data.get('bufferViews', [])
                        buffer_view_idx = pos_accessor['bufferView']
                        buffer_view = buffer_views[buffer_view_idx]

                        buffer_idx = buffer_view.get('buffer', 0)
                        offset = buffer_view.get('byteOffset', 0) + pos_accessor.get('byteOffset', 0)
                        length = buffer_view.get('byteLength', 0)

                        import numpy as np
                        data_bytes = buffers[buffer_idx][offset:offset + length]
                        positions = np.frombuffer(data_bytes, dtype=np.float32)
                        positions = positions.reshape(-1, 3)

                        print(f"  ✓ 位置数据: {len(positions)} 个顶点")
                        print(f"    - 范围: X[{positions.min():.2f}, {positions.max():.2f}], "
                              f"Y[{positions[:, 1].min():.2f}, {positions[:, 1].max():.2f}], "
                              f"Z[{positions[:, 2].min():.2f}, {positions[:, 2].max():.2f}]")

                    if 'NORMAL' in attributes:
                        normal_accessor_idx = attributes['NORMAL']
                        normal_accessor = gltf_data['accessors'][normal_accessor_idx]
                        # 手动读取数据
                        buffer_views = gltf_data.get('bufferViews', [])
                        buffer_view_idx = normal_accessor['bufferView']
                        buffer_view = buffer_views[buffer_view_idx]

                        buffer_idx = buffer_view.get('buffer', 0)
                        offset = buffer_view.get('byteOffset', 0) + normal_accessor.get('byteOffset', 0)
                        length = buffer_view.get('byteLength', 0)

                        import numpy as np
                        data_bytes = buffers[buffer_idx][offset:offset + length]
                        normals = np.frombuffer(data_bytes, dtype=np.float32)
                        normals = normals.reshape(-1, 3)
                        print(f"  ✓ 法线数据: {len(normals)} 个顶点")

                    if 'TEXCOORD_0' in attributes:
                        tex_accessor_idx = attributes['TEXCOORD_0']
                        tex_accessor = gltf_data['accessors'][tex_accessor_idx]
                        # 手动读取数据
                        buffer_views = gltf_data.get('bufferViews', [])
                        buffer_view_idx = tex_accessor['bufferView']
                        buffer_view = buffer_views[buffer_view_idx]

                        buffer_idx = buffer_view.get('buffer', 0)
                        offset = buffer_view.get('byteOffset', 0) + tex_accessor.get('byteOffset', 0)
                        length = buffer_view.get('byteLength', 0)

                        import numpy as np
                        data_bytes = buffers[buffer_idx][offset:offset + length]
                        tex_coords = np.frombuffer(data_bytes, dtype=np.float32)
                        tex_coords = tex_coords.reshape(-1, 2)
                        print(f"  ✓ UV坐标: {len(tex_coords)} 个顶点")

                    if 'JOINTS_0' in attributes:
                        joints_accessor_idx = attributes['JOINTS_0']
                        joints_accessor = gltf_data['accessors'][joints_accessor_idx]
                        # 手动读取数据
                        buffer_views = gltf_data.get('bufferViews', [])
                        buffer_view_idx = joints_accessor['bufferView']
                        buffer_view = buffer_views[buffer_view_idx]

                        buffer_idx = buffer_view.get('buffer', 0)
                        offset = buffer_view.get('byteOffset', 0) + joints_accessor.get('byteOffset', 0)
                        length = buffer_view.get('byteLength', 0)

                        import numpy as np
                        data_bytes = buffers[buffer_idx][offset:offset + length]
                        joints = np.frombuffer(data_bytes, dtype=np.uint8)  # 关节索引通常是unsigned byte
                        joints = joints.reshape(-1, 4)
                        print(f"  ✓ 关节索引: {len(joints)} 个顶点")

                    if 'WEIGHTS_0' in attributes:
                        weights_accessor_idx = attributes['WEIGHTS_0']
                        weights_accessor = gltf_data['accessors'][weights_accessor_idx]
                        # 手动读取数据
                        buffer_views = gltf_data.get('bufferViews', [])
                        buffer_view_idx = weights_accessor['bufferView']
                        buffer_view = buffer_views[buffer_view_idx]

                        buffer_idx = buffer_view.get('buffer', 0)
                        offset = buffer_view.get('byteOffset', 0) + weights_accessor.get('byteOffset', 0)
                        length = buffer_view.get('byteLength', 0)

                        import numpy as np
                        data_bytes = buffers[buffer_idx][offset:offset + length]
                        weights = np.frombuffer(data_bytes, dtype=np.float32)
                        weights = weights.reshape(-1, 4)
                        print(f"  ✓ 权重数据: {len(weights)} 个顶点")

                    if 'indices' in primitive:
                        indices_accessor_idx = primitive['indices']
                        indices_accessor = gltf_data['accessors'][indices_accessor_idx]
                        # 手动读取数据
                        buffer_views = gltf_data.get('bufferViews', [])
                        buffer_view_idx = indices_accessor['bufferView']
                        buffer_view = buffer_views[buffer_view_idx]

                        buffer_idx = buffer_view.get('buffer', 0)
                        offset = buffer_view.get('byteOffset', 0) + indices_accessor.get('byteOffset', 0)
                        length = buffer_view.get('byteLength', 0)

                        import numpy as np
                        # 检查索引类型
                        component_type = indices_accessor.get('componentType', 5123)  # 默认unsigned short
                        if component_type == 5121:  # unsigned byte
                            dtype = np.uint8
                        elif component_type == 5123:  # unsigned short
                            dtype = np.uint16
                        elif component_type == 5125:  # unsigned int
                            dtype = np.uint32
                        else:
                            dtype = np.uint16

                        data_bytes = buffers[buffer_idx][offset:offset + length]
                        indices = np.frombuffer(data_bytes, dtype=dtype)
                        print(f"  ✓ 索引数据: {len(indices)} 个索引")

        print("\n" + "=" * 60)
        print("内部函数测试通过! ✓")
        print("=" * 60)

    except Exception as e:
        print(f"\n✗ 测试失败!")
        print(f"  错误类型: {type(e).__name__}")
        print(f"  错误信息: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_internal_functions()
