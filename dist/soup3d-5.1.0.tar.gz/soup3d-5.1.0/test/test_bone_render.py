"""
测试骨骼绑定渲染功能（需要OpenGL上下文）
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame
import soup3D
from soup3D.skeleton import Bone


def test_bone_rendering():
    """测试骨骼绑定渲染"""
    
    print("初始化Pygame和OpenGL...")
    pygame.init()
    display = (800, 600)
    screen = pygame.display.set_mode(display, pygame.DOUBLEBUF | pygame.OPENGL)
    pygame.display.set_caption("骨骼绑定渲染测试")
    
    # 初始化Soup3D
    soup3D.init(
        width=display[0],
        height=display[1],
        fov=60,
        bg_color=(0.1, 0.1, 0.15)
    )
    
    # 设置相机
    soup3D.camera.goto(0, 0, 5)
    
    # 添加光源
    light = soup3D.light.Cone(
        place=(5, 5, 5),
        toward=(-45, -45, 0),
        color=(1.0, 1.0, 1.0),
        attenuation=0.1,
        angle=60
    )
    light.turn_on()
    
    print("创建骨骼...")
    # 创建简单骨骼
    root = Bone(pos=(0, 0, 0), length=1.0, init_toward=(0, 0, 0))
    child = Bone(pos=root, length=1.0, init_toward=(0, 0, 0))
    
    skeleton = {
        'root': root,
        'child': child
    }
    
    print("创建骨骼绑定着色器...")
    try:
        # 创建骨骼绑定着色器
        shader = soup3D.shader.BoneBinderSP(
            skeleton=skeleton,
            base_color=soup3D.shader.MixChannel((1, 1), 1.0, 0.5, 0.5, 1.0),
            normal=(0.5, 0.5, 1),
            emission=(0, 0, 0),
            double_side=True,
            max_light_count=4,
            max_bone_count=64
        )
        print("✓ 着色器创建成功")
    except Exception as e:
        print(f"✗ 着色器创建失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print("创建顶点数据...")
    # 创建一个简单的三角形
    vertices = [
        # 格式: (bone_weights, x, y, z, u, v, nx, ny, nz)
        ({'root': 1.0}, -1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0),
        ({'root': 0.5, 'child': 0.5}, 1.0, -1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0),
        ({'child': 1.0}, 0.0, 1.0, 0.0, 0.5, 1.0, 0.0, 0.0, 1.0),
    ]
    
    print("创建面和模型...")
    try:
        face = soup3D.Face(
            shape_type="triangle_b",
            surface=shader,
            vertex=vertices
        )
        
        model = soup3D.Model(0, 0, 0, face)
        print("✓ 模型创建成功")
    except Exception as e:
        print(f"✗ 模型创建失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print("\n开始渲染循环（5秒后自动退出）...")
    clock = pygame.time.Clock()
    start_time = pygame.time.get_ticks()
    running = True
    frame_count = 0
    
    try:
        while running:
            # 检查是否超过5秒
            elapsed = pygame.time.get_ticks() - start_time
            if elapsed > 5000:  # 5秒
                running = False
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
            
            # 动画：旋转根骨骼
            angle = (elapsed / 1000.0) * 45  # 每秒45度
            root.turn(angle, 0, 0)
            
            # 渲染
            model.paint()
            soup3D.update()
            
            pygame.display.flip()
            clock.tick(60)
            frame_count += 1
            
            # 每60帧打印一次
            if frame_count % 60 == 0:
                print(f"  已渲染 {frame_count} 帧，骨骼角度: {angle:.1f}°")
    
    except Exception as e:
        print(f"\n✗ 渲染过程中出错: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print(f"\n✓ 测试完成！共渲染 {frame_count} 帧")
    print("如果没有崩溃，说明骨骼绑定渲染功能正常工作！")
    
    pygame.quit()
    return True


if __name__ == '__main__':
    print("=" * 60)
    print("骨骼绑定渲染测试")
    print("=" * 60 + "\n")
    
    try:
        success = test_bone_rendering()
        
        if success:
            print("\n" + "=" * 60)
            print("测试通过！✓")
            print("=" * 60)
        else:
            print("\n" + "=" * 60)
            print("测试失败！✗")
            print("=" * 60)
            sys.exit(1)
    except Exception as e:
        print(f"\n✗ 测试异常: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
