"""
测试修复后的 glTF 骨骼朝向
"""
import sys
import os
sys.path.insert(0, '.')

try:
    import soup3D

    print("=" * 60)
    print("测试 glTF 骨骼朝向修复")
    print("=" * 60)

    # 测试 oren.gltf
    gltf_path = 'test/oren/oren.gltf'

    if not os.path.exists(gltf_path):
        print(f"错误: 文件不存在: {gltf_path}")
        sys.exit(1)

    print(f"\n加载文件: {gltf_path}")

    # 加载模型
    model, skeleton = soup3D.open_gltf(gltf_path)

    print(f"\n✓ 模型加载成功!")
    print(f"  - 面数量: {len(model.faces)}")
    print(f"  - 骨骼数量: {len(skeleton.bones)}")

    # 显示前10个骨骼的朝向
    print(f"\n骨骼朝向 (前10个):")
    for i, (name, bone) in enumerate(list(skeleton.bones.items())[:10]):
        print(f"  [{i}] {name:20s}: init_toward=({bone.init_toward[0]:7.2f}°, {bone.init_toward[1]:7.2f}°, {bone.init_toward[2]:7.2f}°)")

    # 验证朝向是否不同
    toward_values = [bone.init_toward for bone in skeleton.bones.values()]
    unique_towards = set(toward_values)

    print(f"\n验证结果:")
    print(f"  - 总骨骼数: {len(toward_values)}")
    print(f"  - 唯一朝向数: {len(unique_toward)}")

    if len(unique_toward) > len(toward_values) * 0.8:  # 80% 以上的骨骼有不同朝向
        print(f"\n✓ 骨骼朝向修复成功！大部分骨骼都有不同的朝向。")
    else:
        print(f"\n⚠ 警告: 仍然有较多骨骼朝向相同。")

    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)

except Exception as e:
    print(f"\n✗ 加载失败!")
    print(f"  错误类型: {type(e).__name__}")
    print(f"  错误信息: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
