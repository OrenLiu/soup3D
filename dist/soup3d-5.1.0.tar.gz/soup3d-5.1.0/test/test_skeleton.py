"""
骨骼绑定功能测试示例
演示如何创建骨骼系统和使用GLB模型
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pygame
from pygame.locals import *
import soup3D
from soup3D.skeleton import Bone


def test_manual_skeleton():
    """测试手动创建骨骼系统"""
    print("=== 测试手动创建骨骼系统 ===")
    
    # 创建根骨骼
    root_bone = Bone(
        name="root",
        pos=(0, 0, 0),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    # 创建子骨骼
    bone1 = Bone(
        name="bone1",
        pos=(0, 2, 0),
        length=1.5,
        init_toward=(0, 0, 0),
        parent=root_bone
    )
    
    bone2 = Bone(
        name="bone2",
        pos=(0, 1.5, 0),
        length=1.0,
        init_toward=(0, 0, 0),
        parent=bone1
    )
    
    # 获取所有骨骼字典
    skeleton_dict = root_bone.get_all_bones_dict()
    print(f"创建了 {len(skeleton_dict)} 个骨骼:")
    for name in skeleton_dict.keys():
        print(f"  - {name}")
    
    # 设置绑定姿势
    root_bone.set_bind_pose()
    print("绑定姿势已设置")
    
    # 测试旋转
    bone1.turn(yaw=30, pitch=0, roll=0)
    print("bone1 旋转了 30 度 (yaw)")
    
    # 更新骨骼矩阵
    root_bone.update()
    print("骨骼矩阵已更新")
    
    # 获取变换矩阵
    global_mat = bone1.get_global_matrix()
    print(f"bone1 的全局矩阵: {global_mat}")
    
    print("✓ 手动骨骼系统测试通过\n")
    return skeleton_dict


def test_glb_loading(glb_path=None):
    """测试GLB文件加载"""
    print("=== 测试GLB文件加载 ===")
    
    if glb_path is None or not os.path.exists(glb_path):
        print("未提供GLB文件或文件不存在，跳过测试")
        print("提示: 提供一个GLB文件路径来测试完整功能")
        return None, None
    
    try:
        model, skeleton = soup3D.open_glb(
            glb_path,
            double_side=True,
            max_light_count=8,
            max_bone_count=64
        )
        
        print(f"成功加载GLB模型")
        print(f"  - 面数量: {len(model.faces)}")
        print(f"  - 是否有骨骼: {skeleton is not None}")
        
        if skeleton:
            print(f"  - 骨骼数量: {len(skeleton)}")
            print(f"  - 骨骼名称: {', '.join(list(skeleton.keys())[:5])}...")
        
        print("✓ GLB加载测试通过\n")
        return model, skeleton
        
    except Exception as e:
        print(f"✗ GLB加载失败: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def test_rendering_with_skeleton(skeleton_dict=None):
    """测试带骨骼的渲染"""
    print("=== 测试骨骼渲染 ===")
    
    # 初始化pygame和soup3D
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    
    # 初始化soup3D
    soup3D.init(
        width=display[0],
        height=display[1],
        fov=45,
        bg_color=(0.1, 0.1, 0.1),
        near=0.1,
        far=100.0
    )
    
    # 创建相机
    camera = soup3D.camera.Camera()
    camera.goto(0, 0, 10)
    camera.turn(0, 0, 0)
    
    # 如果有骨骼，创建一个简单的测试模型
    if skeleton_dict:
        print("使用提供的骨骼系统")
        from soup3D.shader import BoneBinderSP, MixChannel
        
        # 创建骨骼绑定着色器
        surface = BoneBinderSP(
            skeleton=skeleton_dict,
            base_color=MixChannel((1, 1), 0.8, 0.2, 0.2, 1.0),  # 红色
            normal=(0.5, 0.5, 1),
            emission=(0, 0, 0),
            double_side=True,
            max_light_count=8,
            max_bone_count=64
        )
        
        # 创建一个简单的三角形作为测试
        # 顶点格式: (bone_weights_dict, x, y, z, u, v, nx, ny, nz)
        bone_names = list(skeleton_dict.keys())
        if bone_names:
            # 第一个顶点受第一个骨骼影响
            vertex1 = ({bone_names[0]: 1.0}, -1, -1, 0, 0, 0, 0, 0, 1)
            vertex2 = ({bone_names[0]: 1.0}, 1, -1, 0, 1, 0, 0, 0, 1)
            vertex3 = ({bone_names[0]: 1.0}, 0, 1, 0, 0.5, 1, 0, 0, 1)
            
            face = soup3D.Face(
                shape_type="triangle_b",
                surface=surface,
                vertex=[vertex1, vertex2, vertex3]
            )
            
            model = soup3D.Model(0, 0, 0, face)
            model.show()
            
            print("创建了带骨骼绑定的测试模型")
    else:
        print("没有骨骼系统，创建普通模型")
        # 创建普通模型
        surface = soup3D.shader.AutoSP(
            base_color=soup3D.shader.MixChannel((1, 1), 0.2, 0.8, 0.2, 1.0),  # 绿色
            normal=(0.5, 0.5, 1),
            emission=(0, 0, 0),
            double_side=True,
            max_light_count=8
        )
        
        # 简单三角形
        vertex1 = (-1, -1, 0, 0, 0, 0, 0, 1)
        vertex2 = (1, -1, 0, 1, 0, 0, 0, 1)
        vertex3 = (0, 1, 0, 0.5, 1, 0, 0, 1)
        
        face = soup3D.Face(
            shape_type="triangle_b",
            surface=surface,
            vertex=[vertex1, vertex2, vertex3]
        )
        
        model = soup3D.Model(0, 0, 0, face)
        model.show()
    
    # 添加光源
    light = soup3D.light.Cone()
    light.place = (5, 5, 5)
    light.color = (1.0, 1.0, 1.0)
    light.on = True
    
    # 主循环
    clock = pygame.time.Clock()
    running = True
    frame_count = 0
    
    print("\n开始渲染循环 (按ESC退出)...")
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False
        
        # 动画：旋转骨骼
        if skeleton_dict and frame_count % 60 == 0:
            for bone_name, bone in skeleton_dict.items():
                if bone.parent is not None:  # 只旋转非根骨骼
                    angle = (frame_count // 60) % 360
                    bone.turn(yaw=angle * 0.5, pitch=0, roll=0)
            # 更新骨骼
            for bone in skeleton_dict.values():
                if bone.parent is None:
                    bone.update()
                    break
        
        # 更新
        soup3D.update()
        
        # 刷新显示
        pygame.display.flip()
        clock.tick(60)
        frame_count += 1
    
    pygame.quit()
    print("✓ 渲染测试完成\n")


def main():
    """主测试函数"""
    print("=" * 60)
    print("Soup3D 骨骼绑定功能测试")
    print("=" * 60 + "\n")
    
    # 测试1: 手动创建骨骼
    skeleton_dict = test_manual_skeleton()
    
    # 测试2: 加载GLB文件（如果提供）
    glb_path = None
    if len(sys.argv) > 1:
        glb_path = sys.argv[1]
    
    model, loaded_skeleton = test_glb_loading(glb_path)
    
    # 使用加载的骨骼或手动创建的骨骼
    use_skeleton = loaded_skeleton if loaded_skeleton else skeleton_dict
    
    # 测试3: 渲染
    try:
        test_rendering_with_skeleton(use_skeleton)
    except Exception as e:
        print(f"渲染测试失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("=" * 60)
    print("所有测试完成!")
    print("=" * 60)


if __name__ == '__main__':
    main()
