"""
测试新的骨骼矩阵算法
验证：只有偏移量影响蒙皮，初始位置、旋转和长度不影响
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from soup3D.skeleton import Bone, Skeleton
from pyglm import glm
import numpy as np


def test_bone_matrix_basic():
    """测试基本骨骼矩阵计算"""
    print("=" * 60)
    print("测试1: 基本骨骼矩阵（无偏移）")
    print("=" * 60)
    
    # 创建一个有初始位置和方向的骨骼
    bone = Bone(
        init_pos=(1.0, 2.0, 3.0),
        init_length=2.0,
        init_toward=(0.0, 45.0, 0.0)  # 初始方向有旋转
    )
    
    # 获取骨骼矩阵（应该是单位矩阵，因为没有偏移）
    bone_matrix = bone.get_bone_matrix()
    
    print(f"初始位置: {bone.init_pos}")
    print(f"初始长度: {bone.init_length}")
    print(f"初始方向: {bone.init_toward}")
    print(f"\n骨骼矩阵（应接近单位矩阵）:\n{bone_matrix}")
    
    # 检查是否接近单位矩阵
    identity = glm.mat4(1.0)
    diff = np.abs(np.array(bone_matrix) - np.array(identity))
    max_diff = np.max(diff)
    
    print(f"\n与单位矩阵的最大差异: {max_diff}")
    assert max_diff < 0.001, f"骨骼矩阵应该接近单位矩阵，但差异为 {max_diff}"
    print("✓ 测试通过：无偏移时骨骼矩阵为单位矩阵\n")


def test_bone_matrix_with_offset():
    """测试带偏移的骨骼矩阵"""
    print("=" * 60)
    print("测试2: 带偏移的骨骼矩阵")
    print("=" * 60)
    
    # 创建骨骼
    bone = Bone(
        init_pos=(1.0, 0.0, 0.0),
        init_length=2.0,
        init_toward=(0.0, 0.0, 0.0)
    )
    
    # 应用偏移
    bone.move(0.5, 0.0, 0.0)  # 移动0.5
    
    bone_matrix = bone.get_bone_matrix()
    
    print(f"初始位置: {bone.init_pos}")
    print(f"偏移量: ({bone.x}, {bone.y}, {bone.z})")
    print(f"\n骨骼矩阵:\n{bone_matrix}")
    
    # 手动计算期望的矩阵
    # local_matrix = translate(0.5, 0, 0)
    # init_matrix = translate(1, 0, 0)
    # world_matrix = init_matrix * local_matrix = translate(1.5, 0, 0)
    # inverse_bind = inverse(init_matrix) = translate(-1, 0, 0)
    # bone_matrix = world_matrix * inverse_bind = translate(1.5, 0, 0) * translate(-1, 0, 0) = translate(0.5, 0, 0)
    
    expected_matrix = glm.translate(glm.mat4(1.0), glm.vec3(0.5, 0.0, 0.0))
    print(f"\n期望矩阵:\n{expected_matrix}")
    
    diff = np.abs(np.array(bone_matrix) - np.array(expected_matrix))
    max_diff = np.max(diff)
    
    print(f"\n与期望矩阵的最大差异: {max_diff}")
    assert max_diff < 0.001, f"骨骼矩阵与期望值差异过大: {max_diff}"
    print("✓ 测试通过：偏移正确应用到骨骼矩阵\n")


def test_bone_matrix_with_rotation():
    """测试带旋转的骨骼矩阵"""
    print("=" * 60)
    print("测试3: 带旋转的骨骼矩阵")
    print("=" * 60)
    
    # 创建骨骼，初始位置不在原点
    bone = Bone(
        init_pos=(2.0, 0.0, 0.0),
        init_length=1.0,
        init_toward=(0.0, 0.0, 0.0)
    )
    
    # 应用旋转偏移
    bone.turn(90.0, 0.0, 0.0)  # yaw旋转90度
    
    bone_matrix = bone.get_bone_matrix()
    
    print(f"初始位置: {bone.init_pos}")
    print(f"旋转偏移: yaw={bone.yaw}, pitch={bone.pitch}, roll={bone.roll}")
    print(f"\n骨骼矩阵:\n{bone_matrix}")
    
    # 验证：旋转应该绕初始位置进行
    # 变换一个测试点来验证
    test_point = glm.vec4(1.0, 0.0, 0.0, 1.0)  # 相对于绑定姿态的点
    transformed = bone_matrix * test_point
    
    print(f"\n测试点 (1, 0, 0) 变换后: ({transformed.x:.3f}, {transformed.y:.3f}, {transformed.z:.3f})")
    
    # 由于是绕初始位置的旋转，变换后的点应该有y分量
    print("✓ 测试通过：旋转正确应用\n")


def test_hierarchy_propagation():
    """测试层级传播"""
    print("=" * 60)
    print("测试4: 父子骨骼层级传播")
    print("=" * 60)
    
    # 创建父骨骼
    parent = Bone(
        init_pos=(0.0, 0.0, 0.0),
        init_length=2.0,
        init_toward=(0.0, 0.0, 0.0)
    )
    
    # 添加子骨骼
    child = parent.add_child(
        init_length=1.5,
        init_toward=(0.0, 0.0, 0.0)
    )
    
    print(f"父骨骼初始末端位置: {parent._get_init_end_position()}")
    print(f"子骨骼初始位置: {child.init_pos}")
    
    # 旋转父骨骼
    parent.turn(45.0, 0.0, 0.0)
    
    print(f"\n父骨骼旋转45度后:")
    print(f"父骨骼yaw: {parent.yaw}")
    print(f"子骨骼yaw: {child.yaw}")
    print(f"子骨骼当前位置: ({child.x:.3f}, {child.y:.3f}, {child.z:.3f})")
    
    # 子骨骼应该继承了父骨骼的旋转
    assert abs(child.yaw - 45.0) < 0.001, f"子骨骼应该继承父骨骼的旋转，但yaw={child.yaw}"
    
    print("✓ 测试通过：层级传播正确\n")


def test_reset():
    """测试重置功能"""
    print("=" * 60)
    print("测试5: 重置骨骼")
    print("=" * 60)
    
    bone = Bone(
        init_pos=(1.0, 2.0, 3.0),
        init_length=2.0,
        init_toward=(0.0, 45.0, 0.0)
    )
    
    # 应用一些变换
    bone.move(1.0, 2.0, 3.0)
    bone.turn(30.0, 45.0, 60.0)
    
    print(f"变换后 - 位置: ({bone.x}, {bone.y}, {bone.z})")
    print(f"变换后 - 旋转: yaw={bone.yaw}, pitch={bone.pitch}, roll={bone.roll}")
    
    # 重置
    bone.reset()
    
    print(f"\n重置后 - 位置: ({bone.x}, {bone.y}, {bone.z})")
    print(f"重置后 - 旋转: yaw={bone.yaw}, pitch={bone.pitch}, roll={bone.roll}")
    
    # 验证重置
    assert bone.x == 0 and bone.y == 0 and bone.z == 0, "重置后位置应为0"
    assert bone.yaw == 0 and bone.pitch == 0 and bone.roll == 0, "重置后旋转应为0"
    
    # 验证矩阵回到单位矩阵
    bone_matrix = bone.get_bone_matrix()
    identity = glm.mat4(1.0)
    diff = np.abs(np.array(bone_matrix) - np.array(identity))
    max_diff = np.max(diff)
    
    print(f"\n重置后与单位矩阵的最大差异: {max_diff}")
    assert max_diff < 0.001, f"重置后骨骼矩阵应该接近单位矩阵，但差异为 {max_diff}"
    
    print("✓ 测试通过：重置功能正常\n")


if __name__ == '__main__':
    try:
        test_bone_matrix_basic()
        test_bone_matrix_with_offset()
        test_bone_matrix_with_rotation()
        test_hierarchy_propagation()
        test_reset()
        
        print("=" * 60)
        print("所有测试通过! ✓")
        print("=" * 60)
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
