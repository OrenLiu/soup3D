"""
直接测试 _build_skeleton 返回的骨骼对象
"""
import sys
import os
sys.path.insert(0, '.')

try:
    import soup3D

    print("=" * 60)
    print("测试 _build_skeleton 返回的骨骼长度")
    print("=" * 60)

    gltf_path = 'test/oren/oren.gltf'

    # 手动调用 _build_skeleton（不创建着色器）
    import json
    import struct
    from pyglm import glm

    with open(gltf_path, 'r') as f:
        gltf_data = json.load(f)

    # 读取 buffer
    base_dir = os.path.dirname(gltf_path)
    buffers = []
    buffer_defs = gltf_data.get('buffers', [])
    for buf_def in buffer_defs:
        if 'uri' in buf_def:
            uri = buf_def['uri']
            if uri.endswith('.bin'):
                bin_path = os.path.join(base_dir, uri)
                with open(bin_path, 'rb') as bin_file:
                    buffers.append(bin_file.read())

    # 获取数据
    accessors = gltf_data.get('accessors', [])
    buffer_views = gltf_data.get('bufferViews', [])
    nodes = gltf_data.get('nodes', [])
    skins = gltf_data.get('skins', [])

    # 调用 _build_skeleton
    skin_data = skins[0]
    skeleton = soup3D._build_skeleton(skin_data, nodes, accessors, buffer_views, buffers)

    print(f"\n✓ 骨架构建成功!")
    print(f"  骨骼数量: {len(skeleton.bones)}")

    # 检查前10个骨骼的 length 属性
    print(f"\n前10个骨骼的 length 属性:")
    for i, (name, bone) in enumerate(list(skeleton.bones.items())[:10]):
        print(f"  [{i}] {name:20s}: bone.length={bone.length:.4f}")

    # 统计
    lengths = [bone.length for bone in skeleton.bones.values()]
    non_default_count = sum(1 for l in lengths if abs(l - 1.0) > 0.001)

    print(f"\n统计:")
    print(f"  总骨骼数: {len(lengths)}")
    print(f"  非默认长度(≠1.0)的骨骼数: {non_default_count}")

    if non_default_count > len(lengths) * 0.8:
        print(f"\n✓ 骨骼长度修复成功！{non_default_count}/{len(lengths)} 个骨骼有正确长度。")
    else:
        print(f"\n⚠ 仍有 {len(lengths) - non_default_count} 个骨骼使用默认长度 1.0")

except Exception as e:
    print(f"\n✗ 测试失败!")
    print(f"  错误类型: {type(e).__name__}")
    print(f"  错误信息: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
