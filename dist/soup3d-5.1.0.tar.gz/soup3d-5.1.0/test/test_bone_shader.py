"""
测试 BoneBinderSP 着色器编译
"""
import soup3D
from OpenGL.GL import *

# 初始化 OpenGL 上下文
import pygame
pygame.init()
pygame.display.set_mode((640, 480), pygame.OPENGL | pygame.DOUBLEBUF)
soup3D.init(640, 480)

# 测试 BoneBinderSP 创建
print("创建 BoneBinderSP...")
skeleton = soup3D.skeleton.Skeleton()
root_bone = soup3D.skeleton.Bone((0, 0, 0), 1.0, (0, 0, 0))
skeleton.add_bone("root", root_bone)

bone_shader = soup3D.shader.BoneBinderSP(
    base_color=soup3D.shader.MixChannel((1, 1), 1.0, 1.0, 1.0, 1.0),
    normal=(0.5, 0.5, 1.0),
    emission=(0, 0, 0),
    double_side=True,
    max_light_count=4,
    skeleton=skeleton
)

print("BoneBinderSP 创建成功！")

# 测试使用着色器
print("使用着色器...")
bone_shader.use()
bone_shader.unuse()
print("着色器使用成功！")

# 测试骨骼权重顶点渲染
print("测试骨骼权重顶点渲染...")
skeleton_vertices = [
    ({"root": 1.0}, -0.5, 0.0, 0.0, 0.0, 0.0),
    ({"root": 1.0}, 0.5, 0.0, 0.0, 1.0, 0.0),
    ({"root": 1.0}, 0.0, 1.0, 0.0, 0.5, 1.0),
]

face = soup3D.Face("triangle_b", bone_shader, skeleton_vertices)
model = soup3D.Model(0, 0, -3, face)
model.paint()
soup3D.update()
pygame.display.flip()

print("测试完成！按任意键退出...")
input()

pygame.quit()