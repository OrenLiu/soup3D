"""
测试骨骼绑定功能
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import soup3D
from soup3D.skeleton import Bone


def test_bone_basic():
    """测试基本骨骼功能"""
    print("测试1: 创建根骨骼")
    
    # 创建根骨骼
    root = Bone(
        pos=(0, 0, 0),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    print(f"根骨骼位置: {root.world_pos}")
    print(f"根骨骼长度: {root.length}")
    assert root.world_pos == [0, 0, 0], "根骨骼位置错误"
    print("✓ 根骨骼创建成功\n")


def test_bone_hierarchy():
    """测试骨骼层次结构"""
    print("测试2: 创建骨骼层次结构")
    
    # 创建根骨骼
    root = Bone(
        pos=(0, 0, 0),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    # 创建子骨骼
    child1 = Bone(
        pos=root,
        length=1.5,
        init_toward=(0, 0, 0)
    )
    
    child2 = Bone(
        pos=child1,
        length=1.0,
        init_toward=(0, 0, 0)
    )
    
    print(f"根骨骼位置: {root.world_pos}")
    print(f"子骨骼1位置: {child1.world_pos}")
    print(f"子骨骼2位置: {child2.world_pos}")
    print(f"根骨骼子节点数: {len(root.children)}")
    print(f"子骨骼1子节点数: {len(child1.children)}")
    
    assert len(root.children) == 1, "根骨骼应该有1个子节点"
    assert len(child1.children) == 1, "子骨骼1应该有1个子节点"
    print("✓ 骨骼层次结构创建成功\n")


def test_bone_rotation():
    """测试骨骼旋转"""
    print("测试3: 骨骼旋转")
    
    # 创建简单的骨骼链
    root = Bone(
        pos=(0, 0, 0),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    child = Bone(
        pos=root,
        length=1.5,
        init_toward=(0, 0, 0)
    )
    
    print(f"旋转前 - 子骨骼位置: {child.world_pos}")
    
    # 旋转根骨骼
    root.turn(90, 0, 0)
    
    print(f"旋转后 - 根骨骼角度: yaw={root.yaw}, pitch={root.pitch}, roll={root.roll}")
    print(f"旋转后 - 子骨骼位置: {child.world_pos}")
    
    # 子骨骼位置应该随着父骨骼旋转而更新
    assert child.world_pos != [0, 0, -2.0], "子骨骼位置应该在旋转后改变"
    print("✓ 骨骼旋转功能正常\n")


def test_bone_transform_matrix():
    """测试骨骼变换矩阵"""
    print("测试4: 骨骼变换矩阵")
    
    root = Bone(
        pos=(1, 2, 3),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    # 获取变换矩阵
    matrix = root.get_transform_matrix()
    print(f"根骨骼变换矩阵:\n{matrix}")
    
    # 获取全局变换矩阵
    global_matrix = root.get_global_transform_matrix()
    print(f"根骨骼全局变换矩阵:\n{global_matrix}")
    
    print("✓ 骨骼变换矩阵计算成功\n")


def test_skeleton_dict():
    """测试骨骼字典"""
    print("测试5: 骨骼字典")
    
    # 创建骨骼层次
    root = Bone(
        pos=(0, 0, 0),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    spine = Bone(
        pos=root,
        length=1.5,
        init_toward=(0, 0, 0)
    )
    
    head = Bone(
        pos=spine,
        length=1.0,
        init_toward=(0, 0, 0)
    )
    
    # 创建骨骼字典
    skeleton = {
        'root': root,
        'spine': spine,
        'head': head
    }
    
    print(f"骨骼数量: {len(skeleton)}")
    print(f"骨骼名称: {list(skeleton.keys())}")
    
    assert len(skeleton) == 3, "应该有3个骨骼"
    assert 'root' in skeleton, "应该包含root骨骼"
    assert 'spine' in skeleton, "应该包含spine骨骼"
    assert 'head' in skeleton, "应该包含head骨骼"
    
    print("✓ 骨骼字典创建成功\n")


def test_simple_armature():
    """测试简单骨架（类似手臂）"""
    print("测试6: 简单手臂骨架")
    
    # 肩膀
    shoulder = Bone(
        pos=(0, 0, 0),
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    # 上臂
    upper_arm = Bone(
        pos=shoulder,
        length=2.5,
        init_toward=(0, 0, 0)
    )
    
    # 前臂
    lower_arm = Bone(
        pos=upper_arm,
        length=2.0,
        init_toward=(0, 0, 0)
    )
    
    # 手
    hand = Bone(
        pos=lower_arm,
        length=0.5,
        init_toward=(0, 0, 0)
    )
    
    skeleton = {
        'shoulder': shoulder,
        'upper_arm': upper_arm,
        'lower_arm': lower_arm,
        'hand': hand
    }
    
    print(f"手臂骨骼数量: {len(skeleton)}")
    print(f"肩膀位置: {shoulder.world_pos}")
    print(f"上臂位置: {upper_arm.world_pos}")
    print(f"前臂位置: {lower_arm.world_pos}")
    print(f"手位置: {hand.world_pos}")
    
    # 弯曲手臂
    print("\n弯曲手臂...")
    shoulder.turn(30, 0, 0)
    upper_arm.turn(45, 0, 0)
    
    print(f"弯曲后 - 上臂位置: {upper_arm.world_pos}")
    print(f"弯曲后 - 前臂位置: {lower_arm.world_pos}")
    print(f"弯曲后 - 手位置: {hand.world_pos}")
    
    print("✓ 手臂骨架测试成功\n")


if __name__ == '__main__':
    print("=" * 60)
    print("骨骼绑定功能测试")
    print("=" * 60 + "\n")
    
    try:
        test_bone_basic()
        test_bone_hierarchy()
        test_bone_rotation()
        test_bone_transform_matrix()
        test_skeleton_dict()
        test_simple_armature()
        
        print("=" * 60)
        print("所有测试通过! ✓")
        print("=" * 60)
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
