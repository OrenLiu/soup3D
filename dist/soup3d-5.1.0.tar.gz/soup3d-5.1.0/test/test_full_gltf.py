"""
完整测试：验证 open_gltf 和 gen_skeleton_model 的骨骼长度
"""
import sys
import os
sys.path.insert(0, '.')

try:
    import soup3D

    print("=" * 60)
    print("完整测试：open_gltf + gen_skeleton_model 骨骼长度")
    print("=" * 60)

    gltf_path = 'test/oren/oren.gltf'

    # 调用 open_gltf（会创建着色器，可能需要OpenGL上下文）
    try:
        model, skeleton = soup3D.open_gltf(gltf_path)

        print(f"\n✓ open_gltf 成功!")
        print(f"  模型面数: {len(model.faces)}")
        print(f"  骨骼数量: {len(skeleton.bones)}")

        # 检查前10个骨骼的长度
        print(f"\n前10个骨骼的长度:")
        for i, (name, bone) in enumerate(list(skeleton.bones.items())[:10]):
            print(f"  [{i}] {name:20s}: bone.length={bone.length:.4f}")

        # 统计
        lengths = [bone.length for bone in skeleton.bones.values()]
        non_default = sum(1 for l in lengths if abs(l - 1.0) > 0.001)

        print(f"\n统计:")
        print(f"  总骨骼数: {len(lengths)}")
        print(f"  非默认长度(≠1.0): {non_default}")
        print(f"  默认长度(=1.0): {len(lengths) - non_default}")

        if non_default > len(lengths) * 0.8:
            print(f"\n✓ 骨骼长度正确！")
        else:
            print(f"\n⚠ 仍有 {len(lengths) - non_default} 个骨骼使用默认长度")

        # 测试 gen_skeleton_model
        print(f"\n测试 gen_skeleton_model:")
        skeleton_model = soup3D.gen_skeleton_model(skeleton)
        print(f"  ✓ 骨骼模型创建成功")
        print(f"  模型面数: {len(skeleton_model.faces)}")

        print(f"\n" + "=" * 60)
        print(f"总结:")
        print(f"  如果您看到 '非默认长度(≠1.0)' > 60，")
        print(f"  说明骨骼长度是正确的。")
        print(f"  ")
        print(f"  请检查您的测试代码是否使用:")
        print(f"    for name, bone in skeleton.bones.items():")
        print(f"        print(bone.length)")
        print(f"=" * 60)

    except Exception as e:
        print(f"\n✗ open_gltf 失败!")
        print(f"  错误类型: {type(e).__name__}")
        print(f"  错误信息: {str(e)}")
        print(f"\n注意: 这可能是因为没有 OpenGL 上下文。")
        print(f"  如果是这样，请使用 test/test_build_skeleton.py 测试。")
        import traceback
        traceback.print_exc()

except Exception as e:
    print(f"\n✗ 测试失败!")
    print(f"  错误类型: {type(e).__name__}")
    print(f"  错误信息: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
