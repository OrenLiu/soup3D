"""
测试GLTF模型加载和骨骼绑定
"""
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import soup3D

def test_gltf_loading():
    """测试GLTF文件加载"""
    print("=" * 60)
    print("测试GLTF模型加载")
    print("=" * 60)
    
    gltf_path = "./oren/oren.gltf"
    
    if not os.path.exists(gltf_path):
        print(f"错误: 文件不存在: {gltf_path}")
        return
    
    print(f"\n加载文件: {gltf_path}")
    
    try:
        # 加载模型
        model, skeleton = soup3D.open_gltf(gltf_path)
        
        print(f"\n✓ 模型加载成功!")
        print(f"  - 面数量: {len(model.faces)}")
        print(f"  - 骨骼数量: {len(skeleton)}")
        
        # 打印前10个骨骼名称
        print(f"\n骨骼列表 (前10个):")
        for i, bone_name in enumerate(list(skeleton.keys())[:10]):
            bone = skeleton[bone_name]
            print(f"  [{i}] {bone_name}: pos={bone.pos}, children={len(bone.children)}")
        
        if len(skeleton) > 10:
            print(f"  ... 还有 {len(skeleton) - 10} 个骨骼")
        
        # 检查顶点数据
        total_vertices = 0
        for face in model.faces:
            total_vertices += len(face.vertex)
        
        print(f"\n顶点数据统计:")
        print(f"  - 总顶点数: {total_vertices}")
        
        # 检查第一个面的第一个顶点
        if model.faces and model.faces[0].vertex:
            first_vertex = model.faces[0].vertex[0]
            print(f"\n示例顶点数据:")
            print(f"  - 格式: (bone_weights, x, y, z, u, v, nx, ny, nz)")
            print(f"  - 数据: {first_vertex}")
            
            if isinstance(first_vertex[0], dict):
                bone_weights = first_vertex[0]
                print(f"  - 骨骼权重: {bone_weights}")
        
        print("\n" + "=" * 60)
        print("测试通过! ✓")
        print("=" * 60)
        
        # 询问是否显示模型
        response = input("\n是否显示模型? (y/n): ")
        if response.lower() == 'y':
            print("\n显示模型...")
            model.show()
        
    except Exception as e:
        print(f"\n✗ 加载失败!")
        print(f"  错误类型: {type(e).__name__}")
        print(f"  错误信息: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_gltf_loading()
