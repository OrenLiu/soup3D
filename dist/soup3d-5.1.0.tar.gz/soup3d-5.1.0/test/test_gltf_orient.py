"""
测试修复后的 glTF 骨骼朝向（不创建着色器）
"""
import sys
import os
sys.path.insert(0, '.')

try:
    import json
    import struct
    from pyglm import glm
    import math

    print("=" * 60)
    print("测试 glTF 骨骼朝向修复（纯数据解析）")
    print("=" * 60)

    # 测试 oren.gltf
    gltf_path = 'test/oren/oren.gltf'

    if not os.path.exists(gltf_path):
        print(f"错误: 文件不存在: {gltf_path}")
        sys.exit(1)

    print(f"\n加载文件: {gltf_path}")

    # 读取 glTF 文件
    with open(gltf_path, 'r') as f:
        gltf_data = json.load(f)

    # 读取 buffer 数据
    base_dir = os.path.dirname(gltf_path)
    buffers = []
    buffer_defs = gltf_data.get('buffers', [])
    for buf_def in buffer_defs:
        if 'uri' in buf_def:
            uri = buf_def['uri']
            if uri.endswith('.bin'):
                bin_path = os.path.join(base_dir, uri)
                with open(bin_path, 'rb') as bin_file:
                    buffers.append(bin_file.read())

    # 获取数据
    accessors = gltf_data.get('accessors', [])
    buffer_views = gltf_data.get('bufferViews', [])
    nodes = gltf_data.get('nodes', [])
    skins = gltf_data.get('skins', [])

    # 读取 inverseBindMatrices
    skin_data = skins[0]
    ibm_accessor = accessors[skin_data['inverseBindMatrices']]
    buffer_view = buffer_views[ibm_accessor['bufferView']]
    buffer_index = buffer_view['buffer']
    buffer_data = buffers[buffer_index]
    byte_offset = buffer_view.get('byteOffset', 0) + ibm_accessor.get('byteOffset', 0)
    byte_stride = buffer_view.get('byteStride', 0) or 64
    count = ibm_accessor['count']

    # 读取所有矩阵数据
    inverse_bind_matrices = []
    for i in range(count):
        offset = byte_offset + i * byte_stride
        values = [struct.unpack_from('<f', buffer_data, offset + j * 4)[0] for j in range(16)]
        inverse_bind_matrices.append(values)

    print(f"\n✓ 数据解析成功!")
    print(f"  - 骨骼数量: {count}")

    # 使用修复后的方法计算骨骼朝向
    joint_indices = skin_data.get('joints', [])
    bone_data = []

    for i in range(len(joint_indices)):
        joint_idx = joint_indices[i]
        node = nodes[joint_idx]
        name = node.get('name', f'bone_{i}')

        ibm = inverse_bind_matrices[i]
        ibm_mat4 = glm.mat4(*ibm)
        bind_mat4 = glm.inverse(ibm_mat4)

        # 提取位置
        init_pos = (bind_mat4[3][0], bind_mat4[3][1], bind_mat4[3][2])

        # 从旋转矩阵提取欧拉角
        rot_mat = [
            [bind_mat4[0][0], bind_mat4[0][1], bind_mat4[0][2]],
            [bind_mat4[1][0], bind_mat4[1][1], bind_mat4[1][2]],
            [bind_mat4[2][0], bind_mat4[2][1], bind_mat4[2][2]]
        ]

        yaw = math.degrees(math.atan2(rot_mat[2][0], rot_mat[0][0]))
        pitch = math.degrees(math.atan2(-rot_mat[2][1], math.sqrt(rot_mat[2][2]**2 + rot_mat[1][1]**2)))
        roll = math.degrees(math.atan2(rot_mat[1][2], rot_mat[2][2]))

        bone_data.append((name, (yaw, pitch, roll)))

    # 显示前10个骨骼的朝向
    print(f"\n骨骼朝向 (前10个):")
    for i, (name, toward) in enumerate(bone_data[:10]):
        print(f"  [{i}] {name:20s}: init_toward=({toward[0]:7.2f}°, {toward[1]:7.2f}°, {toward[2]:7.2f}°)")

    # 验证朝向是否不同
    toward_values = [t for _, t in bone_data]
    unique_toward = set(toward_values)

    print(f"\n验证结果:")
    print(f"  - 总骨骼数: {len(toward_values)}")
    print(f"  - 唯一朝向数: {len(unique_toward)}")

    if len(unique_toward) > len(toward_values) * 0.8:
        print(f"\n✓ 骨骼朝向修复成功！{len(unique_toward)}/{len(toward_values)} 个骨骼有不同朝向。")
        print("\n预期结果：每个骨骼都应该指向不同的方向，")
        print("而不是像修复前那样都指向同一个方向。")
        sys.exit(0)
    else:
        print(f"\n⚠ 警告: 仍然有较多骨骼朝向相同。")
        sys.exit(1)

except Exception as e:
    print(f"\n✗ 测试失败!")
    print(f"  错误类型: {type(e).__name__}")
    print(f"  错误信息: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
