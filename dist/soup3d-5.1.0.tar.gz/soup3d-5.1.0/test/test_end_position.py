"""
验证 _get_end_position() 是否正确使用 bone.length
"""
import sys
import os
import math
sys.path.insert(0, '.')

try:
    import soup3D.skeleton as skeleton_module

    print("=" * 60)
    print("验证 _get_end_position() 使用 bone.length")
    print("=" * 60)

    # 创建一个测试骨骼
    test_bone = skeleton_module.Bone(
        init_pos=(0, 0, 0),
        init_length=2.5,
        init_toward=(0, 0, 0)
    )

    print(f"\n创建测试骨骼:")
    print(f"  init_pos:    {test_bone.init_pos}")
    print(f"  init_length: {test_bone.init_length}")
    print(f"  init_toward: {test_bone.init_toward}")
    print(f"  length:      {test_bone.length}")

    # 获取末端位置
    end_pos = test_bone._get_end_position()
    print(f"\n末端位置:")
    print(f"  ({end_pos[0]:.4f}, {end_pos[1]:.4f}, {end_pos[2]:.4f})")

    # 计算实际长度
    actual_length = math.sqrt(
        (end_pos[0] - test_bone.pos.x)**2 +
        (end_pos[1] - test_bone.pos.y)**2 +
        (end_pos[2] - test_bone.pos.z)**2
    )
    print(f"\n验证:")
    print(f"  骨骼长度 (bone.length): {test_bone.length}")
    print(f"  实际距离 (根到末端):     {actual_length:.4f}")

    if abs(actual_length - test_bone.length) < 0.001:
        print(f"\n✓ _get_end_position() 正确使用 bone.length")
    else:
        print(f"\n⚠ 差异: {abs(actual_length - test_bone.length):.4f}")

    # 测试修改长度后的情况
    print(f"\n" + "="*60)
    print("测试修改长度后:")
    print("="*60)

    # 修改长度
    test_bone.length = 5.0
    print(f"设置 bone.length = 5.0")

    end_pos2 = test_bone._get_end_position()
    actual_length2 = math.sqrt(
        (end_pos2[0] - test_bone.pos.x)**2 +
        (end_pos2[1] - test_bone.pos.y)**2 +
        (end_pos2[2] - test_bone.pos.z)**2
    )

    print(f"新的末端位置: ({end_pos2[0]:.4f}, {end_pos2[1]:.4f}, {end_pos2[2]:.4f})")
    print(f"新的实际距离: {actual_length2:.4f}")

    if abs(actual_length2 - 5.0) < 0.001:
        print(f"✓ 修改后的长度被正确应用")
    else:
        print(f"⚠ 差异: {abs(actual_length2 - 5.0):.4f}")

except Exception as e:
    print(f"\n✗ 测试失败!")
    print(f"  错误类型: {type(e).__name__}")
    print(f"  错误信息: {str(e)}")
    import traceback
    traceback.print_exc()
