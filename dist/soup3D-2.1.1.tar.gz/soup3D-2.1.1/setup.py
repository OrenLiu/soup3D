from setuptools import setup

setup(
    name='soup3D',
    version='2.1.1',
    packages=['soup3D']
)

