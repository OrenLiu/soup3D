from setuptools import setup

setup(
    name='soup3D',
    version='2.1.3',
    packages=['soup3D']
)

